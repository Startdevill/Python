print("\n","*"*70,"\n")

set1 = {1, 3, 5, 7, 9}
set2 = {2, 3, 5, 7, 11}

# intersection of sets
print("Intersection:", set1.intersection(set2))

# union of sets
print("Union:", set1.union(set2))

# set difference
print("Set Difference:", set1.difference(set2))

# symmetric difference
print("Symmetric Difference:", set1.symmetric_difference(set2))

# clear a set
set1.clear()
print("Cleared Set 1:", set1)

print("\n","*"*70,"\n")