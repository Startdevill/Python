print("\n","*"*70,"\n")

# Create Set
a = {15,20,30,46,69}
print("Created set :",a)

# Adding Elements From the set
a.add(25)
print("After adding 25 to set a :", a)

# Removing Elements From the set
a.remove(15)
print("After Removing 15 from the set a :", a)

print("\n","*"*70,"\n")