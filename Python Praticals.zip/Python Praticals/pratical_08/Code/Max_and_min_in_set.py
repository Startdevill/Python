print("\n","*"*70,"\n")

s = {25,65,35,161,64,45}
print("The Entered Set is : ", s)

# Finding Maximum value in a set
print("The maximum value in set a :", max(s))

# Finding Minimum value in a set
print("The minimum value in set a :", min(s))

print("\n","*"*70,"\n")