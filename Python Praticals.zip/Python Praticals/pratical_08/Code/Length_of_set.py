print("\n","*"*70,"\n")

s = {25,65,35,61,64,45}
print("The Entered Set is : ", s)

print("The length of the entered set is :",len(s))

print("\n","*"*70,"\n")