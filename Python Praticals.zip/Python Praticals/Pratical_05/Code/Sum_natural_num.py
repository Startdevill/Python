print("\n","*"*70,"\n")

#write a program to find the sum of 10 natural numbers using for loop.
total = 0

for i in range(1, 11):
    total += i

print("The sum of the first 10 natural numbers is:", total)

print("\n","*"*70,"\n")