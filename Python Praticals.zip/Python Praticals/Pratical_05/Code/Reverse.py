print("\n","*"*70,"\n")

# Write a Python program to reverse a given number
n = int(input("Enter a number: "))

reverse = 0
temp = n

while temp > 0:
    
    digit = temp % 10
    reverse = (reverse * 10) + digit
    temp //= 10
print("The reversed number is:", reverse)

print("\n","*"*70,"\n")