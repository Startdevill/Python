print("\n","*"*70,"\n")

# write a Python program take in a number and finds the sum of digits in a number.
n = int(input("Enter a number: "))

sum_of_digits = 0

while n > 0:
    
    digit = n % 10
    sum_of_digits += digit
    n //= 10
    
print("The sum of digits in the number is:", sum_of_digits)

print("\n","*"*70,"\n")