print("\n","*"*70,"\n")

# Print the star pattern

size = 3

# Upper part of the diamond
for i in range(1, size+1):
    for j in range(size-i):
        print(" ", end="")
    for j in range(2*i-1):
        print("*", end="")
    print()

# Lower part of the diamond
for i in range(size-1, 0, -1):
    for j in range(size-i):
        print(" ", end="")
    for j in range(2*i-1):
        print("*", end="")
    print()
    
print("\n","*"*70,"\n")

"""
        *
    *   *   *
*   *   *   *   *
    *   *   *   
        *
"""