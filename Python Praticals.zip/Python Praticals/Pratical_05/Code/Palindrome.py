print("\n","*"*70,"\n")

# Write a Python program that takes a number and checks whether it is a palindrome or not.
n = int(input("Enter a number: "))

n_str = str(n)
n_str_reversed = n_str[::-1]

if n_str == n_str_reversed:
    print("The number is a palindrome.")
else:
    print("The number is not a palindrome.")
    
print("\n","*"*70,"\n")