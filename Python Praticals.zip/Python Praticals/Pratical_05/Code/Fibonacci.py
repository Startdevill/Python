print("\n","*"*70,"\n")

# Write a Python Program to print Fibonacci series
n = int(input("Enter the number of terms: "))
a = 0
b = 1

if n == 1:
    print("Fibonacci series up to", n, "terms:")
    print(a)
else:
    print("Fibonacci series up to", n, "terms:")
    print(a, b, end=" ")
    
    for i in range(2, n):
        c = a + b
        print(c, end=" ")
        a = b
        b = c
        
print("\n","*"*70,"\n")