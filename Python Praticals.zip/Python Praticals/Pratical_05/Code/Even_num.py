print("\n","*"*70,"\n")

# Write a program to print all even numbers between 1 to 100 using while loop
n = 2                  
     
while n <= 100:
    print(n, end=" ")
    n += 2
    
print("\n","*"*70,"\n")