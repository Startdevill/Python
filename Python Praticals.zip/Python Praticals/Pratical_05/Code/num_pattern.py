print("\n","*"*70,"\n")

# Print the following patterns using loop:

n = 7

for i in range(n, 0, -2):
    for j in range((n-i)//2):
        print(" ", end="")
    for j in range(i):
        if j%2 == 0:
            print("1", end="")
        else:
            print("0", end="")
    print()

print("\n","*"*70,"\n")

"""
1010101
 10101
  101
   1
"""