print("\n","*"*70,"\n")

# Write a Python program to calculate factorial of a number
n = int(input("Enter a positive integer: "))

if n < 0:
    print("Invalid input. Please enter a positive integer.")
elif n == 0:
    print("The factorial of 0 is 1.")
else:
    factorial = 1
    
    for i in range(1, n+1):
        factorial *= i
    print("The factorial of", n, "is", factorial)

print("\n","*"*70,"\n")