print("\n","*"*70,"\n")

class Person:
    def __init__(self):
        self.name = input("Enter name: ")
        self.age = input("Enter age: ")
    
    def display(self):
        print("\nName:", self.name)
        print("Age:", self.age)

class Student(Person):
    def __init__(self):
        super().__init__()
        self.roll_no = input("Enter roll number: ")
        self.marks = input("Enter marks: ")
    
    def display(self):
        super().display()
        print("Roll No:", self.roll_no)
        print("Marks:", self.marks)

# Create a Student object and display the information
student = Student()
student.display()

print("\n","*"*70,"\n")