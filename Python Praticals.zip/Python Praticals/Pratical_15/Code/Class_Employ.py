print("\n","*"*70,"\n")
   
class Employee:
    def __init__(self):
        self.name = ""
        self.department = ""
        self.salary = 0
        
    def read_employee(self):
        self.name = input("Enter employee name: ")
        self.department = input("Enter employee department: ")
        self.salary = float(input("Enter employee salary: "))
        
    def print_employee(self):
        print("\nEmployee name:", self.name)
        print("Employee department:", self.department)
        print("Employee salary:", self.salary)

employee = Employee()
employee.read_employee()
employee.print_employee()

print("\n","*"*70,"\n")

'''Create a class Employee with data members: name, department and salary. Create suitable methods for reading and printing employee information'''