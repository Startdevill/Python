print("\n","*"*70,"\n")

class Animal:
    def __init__(self, name):
        self.name = name
    
    def eat(self):
        print(f"{self.name} is eating.")

class Pet:
    def __init__(self, name, owner):
        self.name = name
        self.owner = owner
    
    def play(self):
        print(f"{self.name} is playing with {self.owner}.")
    
class Dog(Animal, Pet):
    def __init__(self, name, owner):
        Animal.__init__(self, name)
        Pet.__init__(self, name, owner)

    def bark(self):
        print(f"{self.name} is barking.")

my_dog = Dog("Lio", "Praful")

my_dog.eat()  
my_dog.bark()
my_dog.play()

print("\n","*"*70,"\n")