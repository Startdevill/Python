print("\n","*"*70,"\n")

''' Write a Python program that will display Calender of given mounth using Calendar Module.'''

def get_college_name():
    college_name = input("What is your college name? ")
    return college_name

def display_college_name(college_name):
    print("Your college name is: ", college_name)

display_college_name("KPCYP")

print("\n","*"*70,"\n")