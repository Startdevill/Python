print("\n","*"*70,"\n")

import calendar

year = int(input("Enter the year: "))
month = int(input("Enter the month: "))
print()

# display the calendar for the given month and year
cal = calendar.month(year, month)
print(cal)

print("*"*70,"\n")