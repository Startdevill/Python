print("\n","*"*70,"\n")

''' Write a Python Program that will calculate area and circumference of circle using inbuilt Math Module'''

import math

radius = float(input("Enter the radius of the circle: "))

area = math.pi * radius ** 2
circumference = 2 * math.pi * radius

print("Area of the circle is:", area)
print("Circumference of the circle is:", circumference)

print("\n","*"*70,"\n")