print("\n","*"*70,"\n")

# Write a Python program to find the highest 3 values in a dictionary.

d = {'a': 100, 'b': 200, 'c': 50, 'd': 300, 'e': 150}
values = sorted(d.values(), reverse=True)

highest_values = values[:3]
print("Highest 3 values in the dictionary:", highest_values)

print("\n","*"*70,"\n")