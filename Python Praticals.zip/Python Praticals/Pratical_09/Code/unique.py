print("\n","*"*70,"\n")
   
data = [{"V": "S001"}, {"V": "S002"}, {"VI": "S001"}, {"VI": "S005"},
        {"VII": "S005"}, {"V": "S009"}, {"VIII": "S007"}]

unique_values = set()

for dictionary in data:
    for value in dictionary.values():
        if value not in unique_values:
            unique_values.add(value)

print("Unique values in the dictionary:", unique_values)

print("\n","*"*70,"\n")

'''Write a Python program to print all unique values in dictionary.
    a. Sample Data:[{"V":"S001"},{"V":"S002"},{"VI":"S001"},{"VI":"S005"},
    {"VII":"S005"},{"V":"S009"},{"VIII":"S007"}]'''