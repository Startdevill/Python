print("\n","*"*70,"\n")

# Write a python Script to sort (ascending and descending) a dictionary by value.

val1 = {'Four':4,'Two':2,'One':1,'Three':3,'Five':5}
print("The entered dictionary is ",val1)

dict_asc = dict(sorted(val1.items(), key=lambda x: x[1]))
dict_desc = dict(sorted(val1.items(), key=lambda x: x[1], reverse=True))

print("Dictionary sorted by value in ascending order:", dict_asc)
print("Dictionary sorted by value in descending order:", dict_desc)

print("\n","*"*70,"\n")