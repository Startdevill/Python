print("\n","*"*70,"\n")

class PrintArea:
    def area_square(self, side):
        print("Area of Square:", side**2)
    
    def area_rectangle(self, length, breadth):
        print("Area of Rectangle:", length * breadth)

# Test the class
p = PrintArea()
p.area_square(5)              
p.area_rectangle(4, 6)  

print("\n","*"*70,"\n")