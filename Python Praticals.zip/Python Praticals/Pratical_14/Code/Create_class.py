print("\n","*"*70,"\n")

class PrintIntegerAndCharacter:
    def __init__(self, n, c):
        self.n = n
        self.c = c
    
    def print_int_char(self):
        print("Integer:", self.n)
        print("Character:", self.c)
    
    def print_char_int(self):
        print("Character:", self.c)
        print("Integer:", self.n)

# Test the class
p = PrintIntegerAndCharacter(10, 'A')
p.print_int_char()
p.print_char_int()

print("\n","*"*70,"\n")