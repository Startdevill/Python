print("\n","*"*70,"\n")

# Write a python program to reverse a list.

list1 = [12,43,54,23,6,78,234]
print("The entered list is :",list1)
list2 = list1[::-1]
print(f"After reversing {list1}", list2)

print("\n","*"*70,"\n")