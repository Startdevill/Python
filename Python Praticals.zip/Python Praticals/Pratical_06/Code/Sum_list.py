print("\n","*"*70,"\n")

# Write a Python Program to sum all the items in a list

list1 = [64,76,67,362,347]

print(f"List before the sum of elements= {list1}")

total = sum(list1)
print(f"The sum of all elements in the List= {total}")

print("\n","*"*70,"\n")