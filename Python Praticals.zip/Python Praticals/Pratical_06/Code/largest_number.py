print("\n","*"*70,"\n")

# Write a Python Program to get the largest number from a list.

def get_largest_number(list1):
    largest_num = list1[0]
    for number in list1:
        if number > largest_num:
            largest_num = number
    return largest_num

list1 = [23,54,21,67,89,34]
print("The Entered list :", list1)
largest_num = get_largest_number(list1)
print("The largest number in given list is :",largest_num)

print("\n","*"*70,"\n")