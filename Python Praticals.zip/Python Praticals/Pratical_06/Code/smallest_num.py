print("\n","*"*70,"\n")

# Write a Python Program to get the Smallest number from a list.

def get_smallest_number(numbers):
    smallest_num = numbers[0]
    for number in numbers:
        if number < smallest_num:
            smallest_num = number
    return smallest_num

numbers = [23,54,21,12,67,89,34]
print("The Entered list :",numbers)
smallest_num = get_smallest_number(numbers)
print ("The smallest number in given list is :",smallest_num)

print("\n","*"*70,"\n")