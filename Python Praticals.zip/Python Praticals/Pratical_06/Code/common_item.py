print("\n","*"*70,"\n")

# Write a python program to find the common is the list.

list1 = [21,23,54,65,76,78]
print("List 1 : ", list1)

list2 = [21,34,65,78,23,67]
print("List 2 : ", list2)

common = []
for i in list1:
    for j in list2:
        if (i==j):
            common.append(i) 

print("Common elements in list_1 and list_2 are : ", common)

print("\n","*"*70,"\n")