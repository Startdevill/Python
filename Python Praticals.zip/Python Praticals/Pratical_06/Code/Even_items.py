print("\n","*"*70,"\n")

# write a python program to find even numbers from the List.

list1 = [25,22,32,45,51,71,92,77,100]
print("The entered list is :", list1)

even = []
for i in list1:
    if i%2 == 0:
        even.append(i)
print("Even items in entered list are :")
    
print("\n","*"*70,"\n")