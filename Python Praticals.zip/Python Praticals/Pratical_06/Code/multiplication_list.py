print("\n","*"*70,"\n")

# Write a Python program to multiplies all the items in a list.

my_list = [23, 47, 64, 81, 10]  

result = 1
for element in my_list:
    result *= element

print(result)

print("\n","*"*70,"\n")