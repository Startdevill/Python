print("\n","*"*70,"\n")

a = (15,20,30,54,66,67)

print("The maximum number is ",max(a))
print("The minimum number is ",min(a))


print("\n","*"*70,"\n")