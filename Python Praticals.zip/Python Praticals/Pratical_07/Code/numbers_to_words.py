print("\n","*"*70,"\n")

number = input("Enter the number : ")
for i in str(number):
    if i == "1":
        print("one", end=" ")
    if i == "2":
        print("Two", end=" ")
    if i == "3":
        print("Thtee", end=" ")        
    if i == "4":
        print("Four", end=" ")
    if i == "5":
        print("Five", end=" ")
    if i == "6":
        print("Six", end=" ")
    if i == "7":
        print("Seven", end=" ")
    if i == "8":
        print("Eight", end=" ")
    if i == "9":
        print("Nine", end=" ")
    if i == "0":
        print("Zero", end=" ")
        
print()
        
print("\n","*"*70,"\n")