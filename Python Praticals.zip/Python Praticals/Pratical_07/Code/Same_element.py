print("\n","*"*70,"\n")

a = (5,5,7,7,7,3,2,5,4)

x=[]
for i in a:
    if i not in x:
        x.append(i)
res=tuple(x)

print(f"The Given tupple is : {a}")
print(f"The tupple afrer removing repeted elements : ",x)

print("\n","*"*70,"\n")