print("\n","*"*70,"\n")

import math

def is_prime(n):
	if n < 2:
		return False
	i = 2
	while i*i <= n:
		if n % i == 0:
			return False
		i += 1
	return True

p = int(input("Enter the number to check is it prime or not : "))

z = is_prime(p)

if z == True:
    print(f"The {p} is a Prime number")
    
elif z == False:
    print(f"The {p} is not a Prime number")

else:
    pass

print("\n","*"*70,"\n")