print("\n","*"*70,"\n")

def factorial(n):
    if n == 1 or n == 0:
        return 1
    else:
        return n * factorial(n-1)
    
n =  int(input("Enter the  number to Get the factorial : "))    

# call the factorial function
result = factorial(n)
print("The factorial of", n, "is", result)

print("\n","*"*70,"\n")