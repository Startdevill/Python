print("\n","*"*70,"\n")

string = input("Enter the string to check the number of cases in sentences : ")

lower=0
upper=0

for i in string:
	if(i.islower()):
			lower+=1
	else:
			upper+=1
print("The number of lowercase characters is:",lower)
print("The number of uppercase characters is:",upper)

print("\n","*"*70,"\n")