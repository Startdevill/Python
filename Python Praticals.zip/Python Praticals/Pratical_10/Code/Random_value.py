print("\n","*"*70,"\n")

import random
import math

random_float = random.uniform(5, 50)
print("Random float between 5 and 50:", random_float)

# Round the random float to 2 decimal places
rounded_float = round(random_float, 2)
print("Random float rounded to 2 decimal places:", rounded_float)

# Use the math module to round down the random float to the nearest integer
int_float = math.floor(random_float)
print("Random float rounded down to the nearest integer:", int_float)

print("\n","*"*70,"\n")