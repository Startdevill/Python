print("\n","*"*70,"\n")

number = int(input("Enter the Number to find Absolute value : "))
print(f"The Absolute value of {number} is ", abs(number))

print("\n","*"*70,"\n")