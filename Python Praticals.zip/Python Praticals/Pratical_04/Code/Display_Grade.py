print("\n","*"*70,"\n")

a = int(input("Enter the First(English) number : "))
b = int(input("Enter the Second(Maths) number : "))
c = int(input("Enter the Third(Science) number : "))
d = int(input("Enter the Fourth(Marathi) number : "))
e = int(input("Enter the Fifth(Compuer) number : "))

total = (a + b + c + d + e)
marks = total / 5
print(f"You scored {total} out off 500")
print(f"And your Precentage is {marks} %")

if marks >= 0 and marks <= 34:
    print("You Failed ")

elif marks >= 35 and marks <= 50:
    print("You secure Grade D")
    
elif marks >= 51 and marks <= 70:
    print("You secure Grade C")
    
elif marks >= 71 and marks <= 87:
    print("You secure Grade B")
    

elif marks >= 88 and marks <= 100:
    print("You secure Grade A")
    
else:
    print("Invallied Input")

print("\n","*"*70,"\n")