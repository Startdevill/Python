print("\n","*"*70,"\n")

a = int(input("Enter the number to check it's nature : "))

if (a > 0):
    print(f"{a} is Positive")
elif (a < 0):
    print(f"{a} is Negative")
else:
    print("Number is zero")

print("\n","*"*70,"\n")