print("\n","*"*70,"\n")

a = int(input("Enter the number to check if it's even or odd : "))

if (a % 2 == 0):
    print(f"{a} is Even")
else:
    print(f"{a} is Odd")

print("\n","*"*70,"\n")