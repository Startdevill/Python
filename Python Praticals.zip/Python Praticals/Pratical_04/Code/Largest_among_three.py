print("\n","*"*70,"\n")

a = int(input("Enter the first number : "))
b = int(input("Enter the second number : "))
c = int(input("Enter the third number : "))

if (a > b) and (a > c):
    print(f"first number {a} is Greater")
elif (b > a) and (b > c):
    print(f"second number {b} is Greater")
else:
    print(f"third number {c} is Greater")

print("\n","*"*70,"\n")