print("\n","*"*70,"\n")

print("MSBTE")

print("\n","*"*70,"\n")