print("\n","*"*70,"\n")

name = input("Please Enter Your Name : ")
print("The Entered Name is ", name)

print("\n","*"*70,"\n")