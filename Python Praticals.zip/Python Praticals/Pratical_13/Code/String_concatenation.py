print("\n","*"*70,"\n")

# Write a Python program to concatenate two string.

string1 = input("Enter the first string: ")
string2 = input("Enter the second string: ")

concatenated_string = string1 + string2
print("The concatenated string is:", concatenated_string)

print("\n","*"*70,"\n")