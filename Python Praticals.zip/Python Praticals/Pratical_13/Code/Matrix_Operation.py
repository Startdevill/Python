print("\n","*"*70,"\n")

import numpy as np

# Defining two matrices
matrix1 = np.array([[1, 2], [3, 4]])
matrix2 = np.array([[5, 6], [7, 8]])

# Matrix addition
addition = np.add(matrix1, matrix2)
print("Matrix addition:\n", addition)

# Matrix subtraction
subtraction = np.subtract(matrix1, matrix2)
print("Matrix subtraction:\n", subtraction)

# Matrix multiplication
multiplication = np.multiply(matrix1, matrix2)
print("Matrix multiplication:\n", multiplication)

# Matrix division
division = np.divide(matrix1, matrix2)
print("Matrix division:\n", division)

print("\n","*"*70,"\n")