print("\n","*"*70,"\n")

# Write a NumPy program to generate six random integers between 10 and 30.

import numpy as np

random_integers = np.random.randint(10, 30, size=6)

print("Random integers between 10 and 30:", random_integers)

print("\n","*"*70,"\n")