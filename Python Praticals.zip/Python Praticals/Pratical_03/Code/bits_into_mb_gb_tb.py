print("\n","*"*70,"\n")

bit = int((input("Enter the number of bits : ")))

print(f"{bit} bits are", bit/8e+6, "in MB's")
print(f"{bit} bits are", bit/8e+9, "in GB's")
print(f"{bit} bits are", bit/8e+12, "in TB's")

print("\n","*"*70,"\n")