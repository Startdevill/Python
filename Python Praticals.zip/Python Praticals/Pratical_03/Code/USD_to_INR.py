print("\n","*"*70,"\n")

usd = float(input("Enter the USD to Convert into INR : "))
print(f"{usd} $ is,", usd * 82.90  ,"RS in INR ")

print("\n","*"*70,"\n")