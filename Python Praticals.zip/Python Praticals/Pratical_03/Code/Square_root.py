print("\n","*"*70,"\n")

# Using Exponential
a = int(input("Enter the Square number to find Square_root : "))
print(f"The Square_root of {a} is", a ** (0.5))

# -------------------------------------------------------------------------

# Using maths module
import math
b = int(input("Enter the Square number to find Square_root : "))
print(f"The Square_root of {b} is", math.sqrt(b))

print("\n","*"*70,"\n")