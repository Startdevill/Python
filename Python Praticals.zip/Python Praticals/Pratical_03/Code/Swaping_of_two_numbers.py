print("\n","*"*70,"\n")

a,b = float(input("Enter the first number : ")) , float(input("Enter the second number : "))
print(f"The value of first and second before Swaping are {a} and {b}")

# Without using third variable
a , b = b , a 
print(f"The value of first and second after Swaping are {a} and {b}")

# ----------------------------------------------------------------------------------------------

# Using Third Variable
c = None
c = a 
a = b 
b = c
del c
print(f"The value of first and second after Swaping are {a} and {b}")

print("\n","*"*70,"\n")