
print("\n","*"*70,"\n")

Side = float(input("Enter the Side of the Square : "))

print(f"The Perimeter of Square with side {Side}  is ", 4 * Side)
print(f"The area of Square with side {Side}  is ", Side * Side)

print("\n","*"*70,"\n")