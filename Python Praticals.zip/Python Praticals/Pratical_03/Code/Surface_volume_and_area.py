
print("\n","*"*70,"\n")

height = float(input("Enter the Height of the Cylinder : "))
radius = float(input("Enter the Radius of the Cylinder : "))

print(f"The Surface volume of Cylinder with Height {height} and Radius {radius} is ", 22/7 * radius**2 * height)
print(f"The area of Cylinder with Height {height} and Radius {radius} is ", 2 * 22/7 * radius * (height + radius))

print("\n","*"*70,"\n")