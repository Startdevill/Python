
print("\n","*"*70,"\n")

length = float(input("Enter the Length of the Rectangle : "))
breadth = float(input("Enter the Breadth of the Rectangle : "))

print(f"The area of Rectangle with Length {length} and Breadth {breadth} is ", length * breadth)

print("\n","*"*70,"\n")