print("\n","*"*70,"\n")

class InvalidPasswordError(Exception):
    pass

def check_password(password):
    correct_password = "Password123" # Replace with your correct password
    if password != correct_password:
        raise InvalidPasswordError("Invalid password. Please try again.")

# Example usage:
try:
    password = input("Enter your password: ")
    check_password(password)
    print("Password is correct!")
except InvalidPasswordError as e:
    print(e)

print("\n","*"*70,"\n")