print("\n","*"*70,"\n")

try:
    x = 10
    y = 0
    z = x/y
    print(z)
except ZeroDivisionError:
    print("Error: Cannot divide by zero.")

print("\n","*"*70,"\n")