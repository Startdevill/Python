print("\n","*"*70,"\n")

import sys
print(sys.version)

print("\n","*"*70,"\n")